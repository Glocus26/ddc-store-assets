Valorant Boot-Animation For Rooted Android. (Hyper-OS not Supported For Now)

---

## Requirememts
- Rooted Android Phone with [Magisk](https://github.com/topjohnwu/Magisk)/[KSU](https://github.com/tiann/KernelSU)/[KSU-N](https://github.com/KernelSU-Next/KernelSU-Next)/[APatch](https://github.com/bmax121/APatch)
- AOSP/MiUI Rom

---

Tested on AOSP/MiUI on POCO F3/Mi 11X/Redmi K40 (Alioth/Aliothin)